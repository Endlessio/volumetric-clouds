#include "glwidget.h"
#include "glm/gtx/string_cast.hpp"
#include "terraingenerator.h"
#include <QOpenGLShaderProgram>
#include <QOpenGLVersionFunctionsFactory>
#include <QOpenGLFunctions_3_1>
#include <QMouseEvent>
#include <QSurfaceFormat>
#include <QDir>
#include <iostream>
#include "src/shaderloader.h"
#include "glm/gtc/matrix_transform.hpp"

GLWidget::GLWidget(QWidget *parent)
    : QOpenGLWidget(parent), m_angleX(0), m_angleY(0), m_zoom(1.0)
{}

GLWidget::~GLWidget() {}

void GLWidget::initializeGL()
{
    m_devicePixelRatio = this->devicePixelRatio();
    // GLEW is a library which provides an implementation for the OpenGL API
    // Here, we are setting it up
    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (err != GLEW_OK) fprintf(stderr, "Error while initializing GLEW: %s\n", glewGetErrorString(err));
    fprintf(stdout, "Successfully initialized GLEW %s\n", glewGetString(GLEW_VERSION));

    // Allows OpenGL to draw objects appropriately on top of one another
    glEnable(GL_DEPTH_TEST);
    glViewport(0, 0, size().width() * m_devicePixelRatio, size().height() * m_devicePixelRatio);
    glClearColor(0, 0, 0, 1);

    const char * vertex_file_path = ":/resources/shader/vertex.vert";
    const char * fragment_file_path = ":/resources/shader/fragment.frag";
    m_shader = ShaderLoader::createShaderProgram(vertex_file_path, fragment_file_path);
    // add texture shader. TODO: organize later
    const char * texture_vertex_file_path = ":/resources/shader/texture.vert";
    const char * texture_fragment_file_path = ":/resources/shader/texture.frag";
    m_texture_shader = ShaderLoader::createShaderProgram(texture_vertex_file_path, texture_fragment_file_path);

    glUseProgram(m_shader);
    m_camera = glm::lookAt(glm::vec3(1,1,1),glm::vec3(0,0,0),glm::vec3(0,0,1));

    m_world = glm::mat4(1.f);
    m_world = glm::translate(m_world, glm::vec3(-0.5, -0.5, 0));

    terrainGeo();
    glUseProgram(m_texture_shader);
    GLint texture_loc = glGetUniformLocation(m_texture_shader, "texture_sampler");
    glUniform1i(texture_loc, 0);
    glUseProgram(0);

    // init FBO
    m_FBO = std::make_unique<FBO>(2, size().width() * m_devicePixelRatio, size().height() * m_devicePixelRatio);
    m_FBO.get()->makeFBO();

}


void GLWidget::terrainGeo() {
    // Create geometry for a sphere

    // Generate and bind the VBO
    glGenBuffers(1, &m_terrain_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m_terrain_vbo);

    // Put data into the VBO
    m_terrain_data = m_terrain.generateTerrain();
    glBufferData(GL_ARRAY_BUFFER,
                 m_terrain_data.size() * sizeof(GLfloat),
                 m_terrain_data.data(),
                 GL_STATIC_DRAW);

    // Generate and bind the VAO, with our VBO currently bound
    glGenVertexArrays(1, &m_terrain_vao);
    glBindVertexArray(m_terrain_vao);

    // Define VAO attributes
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(GLfloat),
                             nullptr);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(GLfloat),
                             reinterpret_cast<void *>(3 * sizeof(GLfloat)));

    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(GLfloat),
                             reinterpret_cast<void *>(6 * sizeof(GLfloat)));

    // Unbind
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void GLWidget::paintGL()
{
    // first paint to get the data
    glBindFramebuffer(GL_FRAMEBUFFER, m_FBO.get()->getFbo());
    glViewport(0, 0, m_FBO.get()->getFBOWidth(), m_FBO.get()->getFBOHeight());

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glUseProgram(m_shader);

    int res = m_terrain.getResolution();

    auto projLoc  = glGetUniformLocation(m_shader, "projMatrix");
    m_proj = glm::perspective(45.0f, (float)width() / height(), 0.01f, 100.f);
    glUniformMatrix4fv(projLoc,  1, GL_FALSE, &m_proj[0][0]);

    std::cout <<" proj " << glm::to_string(m_proj) << "\n";

    glm::mat4 mvMatrix = m_camera*m_world;
    std::cout <<"mv " << glm::to_string(mvMatrix) << "\n";
    auto mvMatrixLoc = glGetUniformLocation(m_shader, "mvMatrix");
    glUniformMatrix4fv(mvMatrixLoc,  1, GL_FALSE, &mvMatrix[0][0]);


    glBindVertexArray(m_terrain_vao);

    glDrawArrays(GL_TRIANGLES, 0, res*res*6);
    glBindVertexArray(0);

//  switch to the default screen
    glBindFramebuffer(GL_FRAMEBUFFER, m_FBO.get()->getDefaultFbo());
    glViewport(0, 0, m_screen_width, m_screen_height);

    paintTexture(m_FBO.get()->getFboTexture());
    glUseProgram(0);
}


void GLWidget::paintTexture(GLuint texture) {
    glUseProgram(m_texture_shader);

    glBindVertexArray(m_FBO.get()->getFullscreenVao());

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);

    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindTexture(GL_TEXTURE_2D, 0);
    glBindVertexArray(0);
    glUseProgram(0);
}

void GLWidget::resizeGL(int w, int h)
{
    m_proj = glm::perspective(45.0f, (float)width() / height(), 0.01f, 100.f);

    m_FBO.get()->deleteRenderBuffer();
    m_FBO.get()->deleteTexture();
    m_FBO.get()->deleteFrameBuffer();
    m_screen_width = size().width() * m_devicePixelRatio;
    m_screen_height = size().height() * m_devicePixelRatio;
    m_FBO.get()->setFboWidth(m_screen_width);
    m_FBO.get()->setFboHeight(m_screen_height);
    m_FBO.get()->makeFBO();
}

void GLWidget::mousePressEvent(QMouseEvent *event) {
    m_prevMousePos = event->pos();
}

void GLWidget::mouseMoveEvent(QMouseEvent *event) {
    m_angleX += 10 * (event->position().x() - m_prevMousePos.x()) / (float) width();
    m_angleY += 10 * (event->position().y() - m_prevMousePos.y()) / (float) height();
    m_prevMousePos = event->pos();
    rebuildMatrices();
}

void GLWidget::wheelEvent(QWheelEvent *event) {
    m_zoom -= event->angleDelta().y() / 100.f;
    rebuildMatrices();
}

void GLWidget::rebuildMatrices() {
    QMatrix4x4 rot;
    rot.setToIdentity();
    rot.rotate(-10 * m_angleX,QVector3D(0,0,1));
    QVector3D eye = QVector3D(1,1,1);
    eye = rot.map(eye);
    rot.setToIdentity();
    rot.rotate(-10 * m_angleY,QVector3D::crossProduct(QVector3D(0,0,1),eye));
    eye = rot.map(eye);

    eye = eye * m_zoom;

    m_camera = glm::mat4(1);
    m_camera = glm::lookAt(glm::vec3(eye[0], eye[1], eye[2]),glm::vec3(0,0,0),glm::vec3(0,0,1));

    m_proj = glm::mat4(1.f);
    m_proj = glm::perspective(45.0f, (float)width() / height(), 0.01f, 100.f);


    update();
}
