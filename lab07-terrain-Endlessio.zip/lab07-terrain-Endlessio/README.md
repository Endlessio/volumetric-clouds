# Lab 7: Terrain

Welcome to Lab 7! The handout for the lab is located [here](https://browncsci1230.github.io/labs/lab7).
